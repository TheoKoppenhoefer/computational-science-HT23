# lu-beamer
Beamer template for Lund University

Run fixfonts to download the non-free fonts used. (on Windows, google "urw-garamond latex")
Also, I guess it might not be completely legal to have those LU-photos on here. Needs to be looked into.
